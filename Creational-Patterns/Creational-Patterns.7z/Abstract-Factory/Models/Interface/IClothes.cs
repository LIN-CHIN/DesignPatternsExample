﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstract_Factory.Models.Interface
{
    public interface IClothes
    {
        public int Defense { get; set; }
        public int weight { get; set; }
        public int GetDefense();
        public int GetWeight();
    }
}
