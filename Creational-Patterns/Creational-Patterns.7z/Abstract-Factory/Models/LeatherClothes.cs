﻿using Abstract_Factory.Models.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abstract_Factory
{
    public class LeatherClothes : IClothes
    {
        public int Defense { get; set; }
        public int weight { get; set; }

        public int GetDefense()
        {
            throw new NotImplementedException();
        }

        public int GetWeight()
        {
            throw new NotImplementedException();
        }
    }
}
