﻿using System;

namespace Abstract_Factory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
